package com.example.apple.week3;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Activity4 extends AppCompatActivity {
    String msg1 = "Lab3";
    String msg2 = "Activity D :";
    EditText ed;
    Button btnveiw;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_4);
        ed = (EditText) findViewById(R.id.location);
        btnveiw = (Button)findViewById(R.id.button3);
        btnveiw.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                try {
                    String address = ed.getText().toString();
                    address = address.replace(' ', '+');
                    Intent geoIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + address));
                    startActivity(geoIntent);
                } catch (Exception e) {
                }
            }
        });
    }
    @Override
    protected void onStart() {
        super.onStart();
        Log.d(msg1,msg2+"OnStart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(msg1,msg2+"OnResume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(msg1,msg2+"OnPause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(msg1,msg2+"OnStop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(msg1,msg2+"OnDestroy");
    }
}
